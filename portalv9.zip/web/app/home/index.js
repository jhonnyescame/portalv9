var Service = function(req, res) {
    res.render('home/index');
};

module.exports = Service;